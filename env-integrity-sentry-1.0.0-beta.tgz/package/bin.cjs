#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');

const { colors, t } = require('./lib/utils.cjs');
const { scanSource } = require('./lib/scanner.cjs');
const { getHash, parseEnv, audit } = require('./lib/verifier.cjs');

const isVerify = process.argv.includes('--verify');
const uploadIdx = process.argv.indexOf('--upload');
const uploadUrl = uploadIdx !== -1 ? process.argv[uploadIdx + 1] : null;

async function verifyLock() {
    const lockPath = path.join(process.cwd(), 'integrity.lock');
    if (!fs.existsSync(lockPath)) {
        console.error(`${colors.red}Error: integrity.lock missing.${colors.reset}`);
        process.exit(1);
    }
    const lockContent = fs.readFileSync(lockPath, 'utf8');
    const lines = lockContent.split(/\r?\n/).filter(l => l.trim());
    let failed = false;

    lines.forEach(line => {
        const [expectedHash, fileName] = line.split(/\s+/);
        const currentHash = getHash(path.join(process.cwd(), fileName));
        if (currentHash !== expectedHash) {
            console.error(`${colors.red}❌ ${t('integrity_failure', { file: fileName })}${colors.reset}`);
            failed = true;
        } else {
            console.log(`${colors.cyan}✅ ${t('integrity_verified')} ${fileName}${colors.reset}`);
        }
    });

    if (failed) process.exit(2); // Integrity Failure
    console.log(`\n${colors.cyan}${t('lock_verified')}${colors.reset}`);
    process.exit(0);
}

if (isVerify) verifyLock();

function upload(url, data) {
    return new Promise((resolve) => {
        const payload = JSON.stringify(data);
        const lib = url.startsWith('https') ? https : http;
        const req = lib.request(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) }
        }, (res) => {
            if (res.statusCode === 200) console.log(`${colors.cyan}Result uploaded.${colors.reset}`);
            resolve();
        });
        req.on('error', () => resolve());
        req.write(payload);
        req.end();
    });
}

async function run() {
    const targetDir = process.argv.filter(a => !a.startsWith('--'))[2] ? path.resolve(process.argv.filter(a => !a.startsWith('--'))[2]) : process.cwd();
    
    const { vars, hardcodedSecrets } = scanSource(targetDir);
    const { missingFromEnv, missingFromAll, activeEnv, exampleEnv } = audit(targetDir, vars);
    const orphans = Object.keys(activeEnv).filter(key => !vars.has(key) && !(key in exampleEnv));

    if (missingFromEnv.length > 0) {
        console.log(`\n${colors.yellow}${t('expected_but_unset')}${colors.reset}`);
        missingFromEnv.forEach(m => console.log(`- ${m.key} [${m.type}]`));
    }

    if (missingFromAll.length > 0) {
        console.log(`\n${colors.red}${t('undocumented_risks')}${colors.reset}`);
        missingFromAll.forEach(m => console.log(`- ${m.key} [${m.type}]`));
    }

    const totalMissing = missingFromEnv.length + missingFromAll.length;
    if (totalMissing > 0) {
        console.log(`\n${colors.red}${t('audit_failed', { count: totalMissing })}${colors.reset}`);
    } else {
        console.log(`\n${colors.green}${t('audit_passed')}${colors.reset}`);
    }

    const result = {
        timestamp: new Date().toISOString(),
        summary: { unexpected_missing: totalMissing, secrets: hardcodedSecrets.length, orphans: orphans.length },
        findings: { missingFromEnv, missingFromAll, hardcodedSecrets, orphans }
    };

    if (process.argv.includes('--report')) {
        console.log(`\n${colors.dim}--- JSON REPORT ---${colors.reset}`);
        console.log(JSON.stringify(result, null, 2));
    }

    if (uploadUrl) await upload(uploadUrl, result);

    const isDrifted = totalMissing > 0 || hardcodedSecrets.length > 0 || orphans.length > 0;
    process.exit(isDrifted ? 1 : 0);
}

run();