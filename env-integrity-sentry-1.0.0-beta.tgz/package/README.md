# Deployment Safety & Drift Enforcement Tool

**Cryptographic Policy Verification and Environment Governance for CI/CD.**

v1.0.0 | Boringly Reliable | Multi-region support active.

## 1. Core Functions
- **Drift Detection**: Identifies missing or undocumented environment variables.
- **Integrity Locking**: SHA-256 verification of core modules.
- **Risk Classification**: Categorizes variables (Runtime, Secret, Optional).
- **CI/CD Enforcement**: Deterministic exit codes for build gating.

## 2. Installation
```bash
git clone https://github.com/aoxendine3/env-integrity-sentry.git
cd env-integrity-sentry
npm install
```

## 3. Usage
### Standard Audit
```bash
node bin.cjs .
```

### Localized Audit (Japanese)
```bash
node bin.cjs . --lang ja
```

### Integrity Verification
```bash
node bin.cjs --verify
```

## 4. Documentation
- [CI/CD Integration](docs/CI_EXAMPLES.md)
- [JSON Schema](docs/SCHEMA.md)
- [Enforcement Policies](docs/POLICIES.md)
- [Exit Codes](docs/EXIT_CODES.md)

---
**Status**: v1.0.0 | DEPLOYMENT READY. Locale detection working.
