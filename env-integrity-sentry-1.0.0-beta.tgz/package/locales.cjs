const locales = {
  en: {
    expected_but_unset: "Expected but Unset (.env):",
    undocumented_risks: "Undocumented Risks (Used in Code):",
    orphaned_variables: "Orphaned Variables (Unused):",
    audit_failed: "Audit failed. {count} variables missing.",
    audit_passed: "Audit passed. No drift detected.",
    integrity_verified: "Integrity Verified:",
    integrity_failure: "Integrity Failure: {file} has been modified.",
    lock_verified: "Lock state verified."
  },
  es: {
    expected_but_unset: "Esperado pero no configurado (.env):",
    undocumented_risks: "Riesgos no documentados (usados en el código):",
    orphaned_variables: "Variables huérfanas (sin uso):",
    audit_failed: "Auditoría fallida. Faltan {count} variables.",
    audit_passed: "Auditoría aprobada. No se detectó desviación.",
    integrity_verified: "Integridad verificada:",
    integrity_failure: "Fallo de integridad: {file} ha sido modificado.",
    lock_verified: "Estado de bloqueo verificado."
  },
  fr: {
    expected_but_unset: "Attendu mais non défini (.env):",
    undocumented_risks: "Risques non documentés (utilisés dans le code):",
    orphaned_variables: "Variables orphelines (non utilisées):",
    audit_failed: "Échec de l'audit. {count} variables manquantes.",
    audit_passed: "Audit réussi. Aucune dérive détectée.",
    integrity_verified: "Intégrité vérifiée:",
    integrity_failure: "Échec d'intégrité: {file} a été modifié.",
    lock_verified: "État de verrouillage vérifié."
  },
  de: {
    expected_but_unset: "Erwartet, aber nicht gesetzt (.env):",
    undocumented_risks: "Undokumentierte Risiken (im Code verwendet):",
    orphaned_variables: "Verwaiste Variablen (unbenutzt):",
    audit_failed: "Audit fehlgeschlagen. {count} Variablen fehlen.",
    audit_passed: "Audit bestanden. Keine Abweichung erkannt.",
    integrity_verified: "Integrität verifiziert:",
    integrity_failure: "Integritätsfehler: {file} wurde geändert.",
    lock_verified: "Sperrzustand verifiziert."
  },
  ja: {
    expected_but_unset: "期待されているが未設定 (.env):",
    undocumented_risks: "未ドキュメントのリスク (コードで使用中):",
    orphaned_variables: "孤立した変数 (未使用):",
    audit_failed: "監査失敗。{count} 個の変数が不足しています。",
    audit_passed: "監査合格。ドリフトは検出されませんでした。",
    integrity_verified: "整合性確認済み:",
    integrity_failure: "整合性エラー: {file} が変更されました。",
    lock_verified: "ロック状態が確認されました。"
  },
  zh: {
    expected_but_unset: "预期但未设置 (.env):",
    undocumented_risks: "未记录的风险 (代码中已使用):",
    orphaned_variables: "孤立变量 (未使用):",
    audit_failed: "审计失败。缺少 {count} 个变量。",
    audit_passed: "审计通过。未检测到配置漂移。",
    integrity_verified: "完整性已验证:",
    integrity_failure: "完整性失败: {file} 已被修改。",
    lock_verified: "锁定状态已验证。"
  },
  ko: {
    expected_but_unset: "예상되었으나 설정되지 않음 (.env):",
    undocumented_risks: "문서화되지 않은 위험 (코드에서 사용됨):",
    orphaned_variables: "분리된 변수 (사용되지 않음):",
    audit_failed: "감사 실패. {count}개의 변수가 누락되었습니다.",
    audit_passed: "감사 통과. 드리프트가 감지되지 않았습니다.",
    integrity_verified: "무결성 확인됨:",
    integrity_failure: "무결성 실패: {file} 파일이 수정되었습니다.",
    lock_verified: "잠금 상태가 확인되었습니다."
  },
  vi: {
    expected_but_unset: "Được mong đợi nhưng chưa đặt (.env):",
    undocumented_risks: "Rủi ro chưa được ghi chép (được dùng trong code):",
    orphaned_variables: "Biến mồ côi (không được dùng):",
    audit_failed: "Kiểm toán thất bại. Thiếu {count} biến.",
    audit_passed: "Kiểm toán thông qua. Không phát hiện độ lệch.",
    integrity_verified: "Đã xác minh tính toàn vẹn:",
    integrity_failure: "Lỗi toàn vẹn: {file} đã bị thay đổi.",
    lock_verified: "Trạng thái khóa đã được xác minh."
  },
  th: {
    expected_but_unset: "ที่คาดไว้แต่ยังไม่ได้ตั้งค่า (.env):",
    undocumented_risks: "ความเสี่ยงที่ไม่ได้บันทึกไว้ (ใช้ในโค้ด):",
    orphaned_variables: "ตัวแปรที่ไม่ได้ใช้งาน:",
    audit_failed: "การตรวจสอบล้มเหลว ขาดหายไป {count} ตัวแปร",
    audit_passed: "ผ่านการตรวจสอบ ไม่พบการเปลี่ยนแปลงที่ไม่พึงประสงค์",
    integrity_verified: "ยืนยันความถูกต้องเรียบร้อยแล้ว:",
    integrity_failure: "ข้อผิดพลาดของความถูกต้อง: {file} ถูกแก้ไข",
    lock_verified: "ยืนยันสถานะการล็อคเรียบร้อยแล้ว"
  }
};

module.exports = locales;
