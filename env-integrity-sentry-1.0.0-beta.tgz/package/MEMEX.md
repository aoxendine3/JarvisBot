# Project Memex: env-integrity-sentry

**Tone and Format: DEEPLOCKED.**

## 1. Deployment Rules
- Identity: Deployment Safety & Drift Enforcement.
- Tone Profile: Technical Minimalist.
- Format: [Project Update, Deployment Rules, Pricing Plan].
- Boundary: Human-approved writes only.
- Footprint: Multi-region support (iad, fra, sin).

## 2. Resolve Strategy
- Architecture: Modular (Scanner / Verifier / Policy / Utils / Orchestrator).
- Enforcement: Deterministic Exit Codes (0, 1, 2).
- Status: v1.0.0 | Pressure tested | Ready for release.

## 3. Style Constraints
- REQUIRED: Technical minimalist tone.
- PROHIBITED: Narrative or promotional adjectives.
- MANDATORY: Verifiable status only.

## 4. Pricing Plan
- Audit ($0), Update ($99), Enforcement ($499).
