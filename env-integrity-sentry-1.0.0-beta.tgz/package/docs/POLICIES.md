# Enforcement Policies & Ignore Rules

v1.0.0 | Deployment Safety & Drift Enforcement

## 1. Risk Classification
Variables are automatically classified to determine enforcement severity.

- **Runtime**: (PORT, DB_URL, HOST) - Critical for execution.
- **Secret**: (API_KEY, SECRET, TOKEN, PASSWORD, CREDENTIAL) - Critical for security.
- **Optional**: (LOG_LEVEL, DEBUG) - Non-blocking.
- **General**: Default classification.

## 2. Ignore Rules
Create a `.env-integrity-ignore` file in your project root to exclude specific variables or directories.

### Example `.env-integrity-ignore`
```bash
# Ignore system variables
LANG
LC_ALL

# Ignore directories
node_modules
dist
.git

# Ignore specific variables
UNUSED_STUB_VAR
```

## 3. Exit Codes
- **0**: Success. No drift or secrets detected.
- **1**: Failure. Drift or hardcoded secrets identified.
- **2**: Integrity. SHA-256 validation failure.
