const { scanSource } = require('../lib/scanner.cjs');
const { audit } = require('../lib/verifier.cjs');
const path = require('path');

async function test() {
  console.log('--- STARTING AUDIT TESTS ---');
  
  const target = path.resolve('.');
  const { vars } = scanSource(target);
  const { missingFromEnv, missingFromAll } = audit(target, vars);

  console.log(`- Variables detected: ${vars.size}`);
  console.log(`- Missing from .env: ${missingFromEnv.length}`);
  console.log(`- Undocumented risks: ${missingFromAll.length}`);

  if (vars.size > 0) {
    console.log('✅ TEST PASSED: Scanner functional.');
  } else {
    console.log('❌ TEST FAILED: No variables detected.');
    process.exit(1);
  }
}

test();
